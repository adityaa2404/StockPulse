---
name: Precision Merchandising Console
colors:
  surface: '#f8f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474a'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777b'
  outline-variant: '#c6c6ca'
  surface-tint: '#5d5e62'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1a1c1f'
  on-primary-container: '#838487'
  inverse-primary: '#c6c6ca'
  secondary: '#0058bb'
  on-secondary: '#ffffff'
  secondary-container: '#1e71e2'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#141c25'
  on-tertiary-container: '#7c858f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e6'
  primary-fixed-dim: '#c6c6ca'
  on-primary-fixed: '#1a1c1f'
  on-primary-fixed-variant: '#45474a'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a41'
  on-secondary-fixed-variant: '#004493'
  tertiary-fixed: '#dae3ef'
  tertiary-fixed-dim: '#bec7d3'
  on-tertiary-fixed: '#141c25'
  on-tertiary-fixed-variant: '#3f4851'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  data-tabular:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: -0.01em
  data-tabular-bold:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: -0.01em
  badge-label:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  caption:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.125rem
  space-sm: 0.25rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style
The brand voice is clinical, authoritative, and obsessively functional. Built specifically for catalog engineers, inventory planners, and algorithmic merchandising operators, the interface treats data density as a primary asset rather than a liability. It strips away ornamental transitions, decorative illustrations, ambient blurs, and skeuomorphic illusions in favor of immediate legibility, structural predictability, and keyboard-first speed.

The design movement is strict Utilitarian Minimalism combined with Modern Systematic Engineering. The emotional response must be total confidence, zero visual fatigue, and immediate situational awareness across massive inventory volumes.

## Colors
The palette is built upon stark neutral contrasts with an intentional avoidance of saturated fills. The canvas rests on `#FFFFFF` with structural subdivisions utilizing `#F6F8FA` and borders locked to `#D0D7DE`. The primary interactive tint is deep carbon `#121417`, ensuring interactive elements carry absolute contrast. Secondary focus and action hooks rely on precision cobalt `#0969DA`.

Status badges employ low-saturation backgrounds paired with high-contrast text and crisp 1px borders:
- **ACTIVE**: Background `#EDF7ED`, Text `#1A7F37`, Border `#B6E3BE`
- **PRICE_REVIEW_PENDING**: Background `#FFF8C5`, Text `#9A6700`, Border `#D4A72C`
- **OUT_OF_STOCK**: Background `#FFEBE9`, Text `#CF222E`, Border `#FF8182`
- **PENDING**: Background `#F0F4F8`, Text `#57606A`, Border `#D0D7DE`
- **ACCEPTED**: Background `#E6FFFA`, Text `#0D766E`, Border `#5EEAD4`
- **REJECTED**: Background `#FFF1E5`, Text `#BC4C00`, Border `#FDBA74`

## Typography
Type is deployed with uncompromising density and tabular precision. Headings and descriptive UI elements utilize `Geist` for its clinical geometry and tight horizontal metrics. All quantitative values, product SKUs, currency amounts, timestamps, and status codes are rendered strictly in `JetBrains Mono` to ensure flawless vertical column alignment across dense tabular surfaces.

Numbers must always enforce tabular sizing (`tnum`). Type hierarchy relies on optical weight shifting (`400` to `600`) and slight tint shifts rather than extreme size differentials.

## Layout & Spacing
The layout follows a fluid-column structural grid pinned to a strict 4px horizontal and vertical baseline. Viewports prioritize multi-monitor operator screens (1440px to 2560px), defaulting to zero horizontal page margins with content bounded directly by panel edges. 

The console operates on a persistent modular split:
- **Utility Rail**: Fixed 48px width, icon-based, collapsed state priority.
- **Tree/Filter Sidebar**: 240px fixed width, fluid vertical scroll, collapsing entirely at viewports under 1024px.
- **Data Workspace**: Fluid canvas spanning 100% of remaining width. Grid columns snap along 12 fluid tracks with a compact 12px gutter. Table cells use dense 6px vertical padding to optimize above-the-fold visibility.

## Elevation & Depth
Elevation is strictly zero-shadow and planar. Visual hierarchy is established exclusively through surface tone transitions and precise hairline outlines.

- **Primary Canvas**: `#FFFFFF`
- **Recessed Toolbars & Headers**: `#F6F8FA`
- **Hovered Table Rows & Elements**: `#F3F4F6`
- **Structural Separation**: 1px solid borders (`#D0D7DE`).
- **Modal Panels & Flyout Drawers**: Rendered on `#FFFFFF` with a 1px solid `#8C959F` stroke, accompanied by a planar 20% `#121417` backdrop tint. Ambient drop shadows and blur backdrops are strictly prohibited.

## Shapes
Geometry is disciplined, utilitarian, and near-sharp. Base UI containers, table cells, metric strips, and nested views utilize `0px` radius (hard corners) to align cleanly with grid seams. 

Interactive controls, discrete inputs, and status badges utilize the `1` (Soft) profile, enforcing an exact `2px` or `4px` corner radius. Full pills, large rounds, and circular interactive containers are prohibited to maintain the architectural, industrial identity of a production control console.

## Components

### Data Tables
Tables are the operational heart of the console. Column headers sit on `#F6F8FA` backgrounds with top and bottom 1px `#D0D7DE` borders, using `11px` bold uppercase labels. Rows feature a constant 32px height, with numbers right-aligned in `JetBrains Mono`. Hover triggers immediate background change to `#F3F4F6` without animated transitions. Active row selection highlights cell background to `#EBF5FF` with a left 3px `#0969DA` indicator.

### Status Badges
Badges are rendered in monospace uppercase (`11px` JetBrains Mono, weight 600) with 2px corner radius, exactly 2px 6px padding, and an explicit 1px border. No pill shapes or glow filters are permitted.
- `ACTIVE`: `#EDF7ED` surface, `#1A7F37` text, `#B6E3BE` border
- `PRICE_REVIEW_PENDING`: `#FFF8C5` surface, `#9A6700` text, `#D4A72C` border
- `OUT_OF_STOCK`: `#FFEBE9` surface, `#CF222E` text, `#FF8182` border
- `PENDING`: `#F0F4F8` surface, `#57606A` text, `#D0D7DE` border
- `ACCEPTED`: `#E6FFFA` surface, `#0D766E` text, `#5EEAD4` border
- `REJECTED`: `#FFF1E5` surface, `#BC4C00` text, `#FDBA74` border

### Buttons
- **Primary**: Background `#121417`, text `#FFFFFF`, 4px radius, 0 10px padding, 28px height. Active: `#24292F`. Focus: 2px `#0969DA` outer ring.
- **Secondary**: Background `#FFFFFF`, border 1px solid `#D0D7DE`, text `#24292F`. Hover: `#F6F8FA`.
- **Destructive**: Background `#FFFFFF`, border 1px solid `#CF222E`, text `#CF222E`. Hover: `#FFEBE9`.

### Input Fields & Search Bars
Inputs utilize 28px height, 1px solid `#D0D7DE` borders, 4px corner radius, and monospace input text for numerical/SKU fields. Focus immediately changes the border to `#0969DA` with zero box-shadow spread.

### Checkboxes & Selection Controls
Checkboxes are hard-bordered 14x14px squares with 2px radius. Unchecked state is `#FFFFFF` with `#D0D7DE` border; checked state is `#121417` with a crisp `#FFFFFF` check icon.

### KPI Metric Blocks
Contained in a single-row continuous ribbon divided by vertical 1px `#D0D7DE` rules without card cards or drop shadows. Metrics show tabular primary values in `18px` JetBrains Mono with 11px uppercase metadata labels sitting directly above.